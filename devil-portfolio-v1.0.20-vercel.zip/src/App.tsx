import { useCallback, useEffect, useRef, useState } from 'react'
import { Navigation } from './components/Navigation'
import { ContactPage } from './pages/ContactPage'
import { HomePage } from './pages/HomePage'
import { LinksPage } from './pages/LinksPage'
import { MusicPage } from './pages/MusicPage'
import { ProjectsPage } from './pages/ProjectsPage'
import { StackPage } from './pages/StackPage'
import type { PageId } from './types'

const pageIds = new Set<PageId>(['home', 'music', 'projects', 'stack', 'links', 'contact'])
const pageOrder: PageId[] = ['home', 'projects', 'stack', 'links', 'contact', 'music']

function readPageFromHash(): PageId {
  const value = window.location.hash.slice(1) as PageId
  return pageIds.has(value) ? value : 'home'
}

function App() {
  const [activePage, setActivePage] = useState<PageId>(readPageFromHash)
  const stageRef = useRef<HTMLDivElement>(null)
  const previousPageRef = useRef(activePage)
  const transitionDirection = pageOrder.indexOf(activePage) >= pageOrder.indexOf(previousPageRef.current) ? 'forward' : 'backward'

  useEffect(() => {
    const handleHashChange = () => setActivePage(readPageFromHash())
    window.addEventListener('hashchange', handleHashChange)
    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [])

  useEffect(() => {
    previousPageRef.current = activePage
  }, [activePage])

  useEffect(() => {
    const handlePointerMove = (event: PointerEvent) => {
      const target = (event.target as HTMLElement).closest<HTMLElement>('.glint')
      if (!target) return
      const rect = target.getBoundingClientRect()
      target.style.setProperty('--glint-x', `${event.clientX - rect.left}px`)
      target.style.setProperty('--glint-y', `${event.clientY - rect.top}px`)
    }
    document.addEventListener('pointermove', handlePointerMove, { passive: true })
    return () => document.removeEventListener('pointermove', handlePointerMove)
  }, [])

  const navigate = useCallback((page: PageId) => {
    if (page === activePage) return
    window.location.hash = page
    setActivePage(page)
    stageRef.current?.focus({ preventScroll: true })
  }, [activePage])

  return (
    <div className="app-shell">
      <div className="texture" aria-hidden="true" />
      <main className="page-stage" ref={stageRef} tabIndex={-1}>
        <MusicPage isActive={activePage === 'music'} transitionDirection={transitionDirection} />
        {activePage !== 'music' ? <div key={activePage} className={`page-transition page-transition-${transitionDirection}`}>
          {activePage === 'home' ? <HomePage onOpenProjects={() => navigate('projects')} /> : null}
          {activePage === 'projects' ? <ProjectsPage /> : null}
          {activePage === 'stack' ? <StackPage /> : null}
          {activePage === 'links' ? <LinksPage /> : null}
          {activePage === 'contact' ? <ContactPage /> : null}
        </div> : null}
      </main>
      <Navigation activePage={activePage} onNavigate={navigate} />
    </div>
  )
}

export default App
