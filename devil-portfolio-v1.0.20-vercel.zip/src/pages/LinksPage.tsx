import { ArrowUpRight } from 'lucide-react'
import { PageHeading } from '../components/PageHeading'
import { portfolioConfig } from '../config'

const badgeImages: Record<'discord' | 'github' | 'profile', string> = { discord: '/discord-badge.png', github: '/github-badge.png', profile: '/guns-badge.png' }

export function LinksPage() {
  return <section className="page content-page narrow-page" aria-labelledby="links-title">
    <PageHeading id="links-title" number="03" eyebrow="find me" title="links" description="everywhere i actually post or reply." />
    <div className="social-list">{portfolioConfig.socialLinks.map((link) => <a className="social-row glint" href={link.url} target="_blank" rel="noreferrer" key={link.id}>
      <span className="social-avatar-wrap"><img className="social-avatar" src={portfolioConfig.avatarUrl} alt="" width="736" height="736" /><span className={`social-avatar-badge social-avatar-badge-${link.id}`} aria-hidden="true"><img className="platform-badge-image" src={badgeImages[link.id]} alt="" /></span></span>
      <span className="social-copy"><strong>{link.label}</strong><span>{link.handle}</span><small>{link.description}</small></span><ArrowUpRight size={20} aria-hidden="true" />
    </a>)}</div>
  </section>
}
