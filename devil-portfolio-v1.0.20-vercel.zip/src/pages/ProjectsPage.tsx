import { useMemo, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { PageHeading } from '../components/PageHeading'
import { portfolioConfig } from '../config'
import type { Project } from '../types'

const filters = [
  { id: 'all', label: 'all' }, { id: 'ai', label: 'ai systems' }, { id: 'discord', label: 'discord' },
  { id: 'minecraft', label: 'minecraft' }, { id: 'android', label: 'android' }, { id: 'desktop', label: 'desktop' },
] as const

function ProjectCard({ project, featured = false }: { project: Project; featured?: boolean }) {
  return <article className={`project-card glint${featured ? ' project-card-featured' : ''}`}>
    <div className="project-topline"><div><h2>{project.title}</h2><span className="project-year">{project.year}</span></div><span className="project-category">{project.category}</span></div>
    <p className="project-status"><i aria-hidden="true" /> {project.status}</p>
    <p className="project-summary">{project.summary}</p>
    <ul className="project-features">{project.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
    <div className="project-tags">{project.technologies.map((technology) => <span className="tech-tag glint" key={technology}>{technology}</span>)}</div>
    <a className="project-arrow" href={`#${project.id}`} aria-label={`view ${project.title}`}><ArrowUpRight size={16} aria-hidden="true" /></a>
  </article>
}

export function ProjectsPage() {
  const [filter, setFilter] = useState<(typeof filters)[number]['id']>('all')
  const visibleProjects = useMemo(() => portfolioConfig.projects.filter((project) => filter === 'all' || project.category === filter), [filter])
  const featured = visibleProjects.find((project) => project.featured)
  const secondary = visibleProjects.filter((project) => project.id !== featured?.id)
  return <section className="page projects-page" aria-labelledby="projects-title">
    <PageHeading id="projects-title" number="02" eyebrow="my work" title="projects" description="commissions, client stuff, and things i made because i wanted them to exist." />
    <div className="project-scroll-area">
      <div className="project-filters" role="toolbar" aria-label="filter projects"><span className="commission-status"><i aria-hidden="true" /> taking commissions</span>{filters.map((item) => <button className={`filter-pill${filter === item.id ? ' is-active' : ''}`} type="button" key={item.id} aria-pressed={filter === item.id} onClick={() => setFilter(item.id)}>{item.label}</button>)}</div>
      <p className="project-kicker">flagship work</p>
      {featured ? <ProjectCard project={featured} featured /> : null}
      {secondary.length ? <div className="project-grid">{secondary.map((project) => <ProjectCard project={project} key={project.id} />)}</div> : null}
    </div>
  </section>
}
