import { ArrowRight, Github, MessageCircle } from 'lucide-react'
import { portfolioConfig } from '../config'

interface HomePageProps { onOpenProjects: () => void }

export function HomePage({ onOpenProjects }: HomePageProps) {
  const social = Object.fromEntries(portfolioConfig.socialLinks.map((link) => [link.id, link]))
  const aboutParts = portfolioConfig.aboutText.split(/(17-year-old|discord)/gi)

  return (
    <section className="page home-page" aria-labelledby="home-title">
      <div className="home-identity">
        <div className="avatar-frame glint"><img src={portfolioConfig.avatarUrl} alt={`${portfolioConfig.displayName}'s profile picture`} width="736" height="736" /></div>
        <p className="eyebrow home-eyebrow"><span aria-hidden="true" /> hey there</p>
        <h1 id="home-title">{portfolioConfig.displayName.toLowerCase()}</h1>
        <p className="handle">{portfolioConfig.handle.toLowerCase()}</p>
      </div>
      <article className="about-card glint"><p>{aboutParts.map((part, index) => {
        if (part.toLowerCase() === '17-year-old') return <strong className="about-highlight" key={`${part}-${index}`}>{part}</strong>
        if (part.toLowerCase() === 'discord') return <a className="about-inline-link" href={social.discord.url} target="_blank" rel="noreferrer" key={`${part}-${index}`}>{part}</a>
        return part
      })}</p></article>
      <div className="home-actions" aria-label="portfolio actions">
        <a className="mini-button glint" href={social.discord.url} target="_blank" rel="noreferrer"><MessageCircle size={14} aria-hidden="true" /> discord</a>
        <a className="mini-button glint" href={social.github.url} target="_blank" rel="noreferrer"><Github size={14} aria-hidden="true" /> github</a>
        <span className="mini-button availability"><i aria-hidden="true" /> {portfolioConfig.status.toLowerCase()}</span>
        <button className="work-button glint" type="button" onClick={onOpenProjects}>my work <ArrowRight size={15} aria-hidden="true" /></button>
      </div>
    </section>
  )
}
