import { useState } from 'react'
import { ExternalLink } from 'lucide-react'
import { PageHeading } from '../components/PageHeading'

const collections = [
  { id: '7cHWpjlm7bWzOSAsLSxz7h', type: 'playlist', label: 'trending hindi', title: 'Trending Hindi Songs', creator: 'playlist by Music' },
  { id: '4pMcx8gDzLJ5k1wMctJhwd', type: 'playlist', label: 'english', title: 'Devil best English songs', creator: 'playlist by Devil' },
  { id: '4Ta7ximL6sf0o1xT8yovxi', type: 'album', label: '305', title: '305', creator: '1nine08 · single' },
  { id: '37i9dQZF1E4ANtHWm6KA1P', type: 'playlist', label: 'seedhe maut', title: 'Seedhe Maut Radio', creator: 'spotify radio' },
  { id: '2uDrmFKA2WbPld7BUnpibn', type: 'playlist', label: 'sad songs', title: 'Sad songs', creator: 'playlist by Devil' },
  { id: '4XdSknjGdJjJynLdumLGQM', type: 'playlist', label: 'phonks', title: 'Best phonks', creator: 'playlist by Devil' },
  { id: '6DG0D5fzMVWQBoQHcezYqB', type: 'album', label: 'españa', title: 'MONTAGEM ESPAÑA', creator: 'h6itam · EP' },
  { id: '0GEyzsE57BwmCPY5LujrHv', type: 'playlist', label: '69', title: '69', creator: 'playlist by Devil' },
  { id: '4MjgNoa0aVbPFzaXRvyZoZ', type: 'playlist', label: 'bollywood', title: 'Famous Bollywood songs', creator: 'playlist by Devil' },
  { id: '1RoCsx3ZQfcIXQMSx02h5A', type: 'playlist', label: 'top hindi', title: 'Top hindi music', creator: 'playlist by Devil' },
  { id: '1NzkgvU1IY19TwWfLSVgbI', type: 'playlist', label: '2010 hits', title: '2010 best songs', creator: 'playlist by Devil' },
  { id: '3mpMvyPWtxJnL3vywQHH5K', type: 'album', label: 'P4', title: 'PARTYNEXTDOOR 4 (P4)', creator: 'PARTYNEXTDOOR · 2024' },
] as const

interface MusicPageProps { isActive: boolean; transitionDirection: 'forward' | 'backward' }

export function MusicPage({ isActive, transitionDirection }: MusicPageProps) {
  const [activeId, setActiveId] = useState<string>(collections[0].id)
  const [loadedIds, setLoadedIds] = useState<string[]>([collections[0].id])
  const activeCollection = collections.find((collection) => collection.id === activeId) ?? collections[0]
  const spotifyUrl = `https://open.spotify.com/${activeCollection.type}/${activeCollection.id}`
  const selectCollection = (id: string) => { setActiveId(id); setLoadedIds((currentIds) => currentIds.includes(id) ? currentIds : [...currentIds, id]) }

  return <section className={`page content-page narrow-page playlist-page${isActive ? ` page-transition page-transition-${transitionDirection}` : ' is-background-player'}`} aria-labelledby="music-title" aria-hidden={!isActive} hidden={!isActive}>
    <PageHeading id="music-title" number="01" eyebrow="on repeat" title="music" description="albums and playlists in rotation. pick one, press play, and keep browsing." />
    <div className="music-library" role="toolbar" aria-label="choose a Spotify collection">{collections.map((collection) => <button key={collection.id} className={activeCollection.id === collection.id ? 'is-active' : undefined} type="button" aria-pressed={activeCollection.id === collection.id} onClick={() => selectCollection(collection.id)}>{collection.label}</button>)}</div>
    <div className="playlist-panel glint"><div className="playlist-header"><span><small>selected {activeCollection.type}</small><strong>{activeCollection.title}</strong><em>{activeCollection.creator}</em></span><a href={spotifyUrl} target="_blank" rel="noreferrer">open spotify <ExternalLink size={14} aria-hidden="true" /></a></div>
      <div className="spotify-frame-stage">{loadedIds.map((id) => { const collection = collections.find((item) => item.id === id); if (!collection) return null; return <iframe key={collection.id} className={`spotify-frame${activeCollection.id === collection.id ? ' is-active' : ''}`} title={`${collection.title} on Spotify`} src={`https://open.spotify.com/embed/${collection.type}/${collection.id}?utm_source=generator&theme=0`} width="100%" height="352" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy" tabIndex={activeCollection.id === collection.id ? 0 : -1} aria-hidden={activeCollection.id !== collection.id} /> })}</div>
    </div>
  </section>
}
