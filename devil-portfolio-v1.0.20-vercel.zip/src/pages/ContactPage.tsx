import { ArrowUpRight, Copy, MessageCircle, Send } from 'lucide-react'
import { useState } from 'react'
import { PageHeading } from '../components/PageHeading'
import { portfolioConfig } from '../config'

export function ContactPage() {
  const [copied, setCopied] = useState(false)
  const social = Object.fromEntries(portfolioConfig.socialLinks.map((link) => [link.id, link]))
  const copyHandle = async () => { await navigator.clipboard?.writeText(social.discord.handle); setCopied(true); window.setTimeout(() => setCopied(false), 1600) }
  return <section className="page content-page narrow-page" aria-labelledby="contact-title">
    <PageHeading id="contact-title" number="04" eyebrow="get in touch" title="contact" description="got something you want built, or just want to talk about a project? my dms are open." />
    <div className="contact-grid">
      <div className="contact-primary glint">
        <span className="contact-avatar-wrap"><img className="contact-avatar" src={portfolioConfig.avatarUrl} alt="" width="736" height="736" /><span className="contact-avatar-badge"><MessageCircle size={13} aria-hidden="true" /></span></span>
        <span className="contact-primary-copy"><small>preferred contact</small><strong>{social.discord.handle}</strong><em>usually the fastest way to reach me.</em><span className="contact-actions"><button type="button" onClick={copyHandle}><Copy size={14} aria-hidden="true" /> {copied ? 'copied' : 'copy handle'}</button><a href={social.discord.url} target="_blank" rel="noreferrer"><Send size={14} aria-hidden="true" /> open</a></span></span>
      </div>
      <div className="contact-secondary-grid">
        <a className="contact-secondary glint" href={social.github.url} target="_blank" rel="noreferrer"><span className="contact-secondary-avatar"><img src={portfolioConfig.avatarUrl} alt="" width="736" height="736" /><span className="contact-secondary-badge"><img src="/github-badge.png" alt="" /></span></span><span><small>github</small><strong>{social.github.handle}</strong></span><ArrowUpRight size={18} aria-hidden="true" /></a>
        <a className="contact-secondary glint" href={social.profile.url} target="_blank" rel="noreferrer"><span className="contact-secondary-avatar"><img src={portfolioConfig.avatarUrl} alt="" width="736" height="736" /><span className="contact-secondary-badge guns-badge"><img src="/guns-badge.png" alt="" /></span></span><span><small>guns.lol</small><strong>{social.profile.handle}</strong></span><ArrowUpRight size={18} aria-hidden="true" /></a>
      </div>
    </div>
  </section>
}
