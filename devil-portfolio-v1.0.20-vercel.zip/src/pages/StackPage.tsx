import { capabilities, skillGroups } from '../data'
import { PageHeading } from '../components/PageHeading'

export function StackPage() {
  return (
    <section className="page content-page" aria-labelledby="stack-title">
      <PageHeading id="stack-title" number="02" eyebrow="toolkit" title="stack" description="tools i’ve actually built things with — not just tried once." />
      <div className="stack-layout">
        <div className="skill-panel">{skillGroups.map((group) => <div className="skill-row" key={group.name}><h2>{group.name}</h2><div className="tag-list">{group.skills.map((skill) => <span className="tech-tag glint" key={skill}>{skill}</span>)}</div></div>)}</div>
        <div className="capability-grid">{capabilities.map((item) => <article className="capability-card glint" key={item.title}><span>{item.number}</span><h2>{item.title}</h2><p>{item.copy}</p></article>)}</div>
      </div>
    </section>
  )
}
