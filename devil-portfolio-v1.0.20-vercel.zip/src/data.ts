import { portfolioConfig } from './config'

export const skillGroups = portfolioConfig.skills
export const capabilities = portfolioConfig.capabilities
export const socialLinks = portfolioConfig.socialLinks
