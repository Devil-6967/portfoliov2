import type { Project } from './types'

export interface PortfolioConfig {
  displayName: string
  handle: string
  age: string
  status: string
  aboutTitle: string
  aboutText: string
  avatarUrl: string
  skills: Array<{ name: string; skills: string[] }>
  capabilities: Array<{ number: string; title: string; copy: string }>
  socialLinks: Array<{ id: 'discord' | 'github' | 'profile'; label: string; handle: string; description: string; url: string }>
  projects: Project[]
}

declare global {
  interface Window { YAHYA_PORTFOLIO_CONFIG?: Partial<PortfolioConfig> }
}

const defaults: PortfolioConfig = {
  displayName: 'Devil',
  handle: '@devilsuckss',
  age: '17',
  status: 'Open to discuss projects',
  aboutTitle: 'I build useful things across code and communities.',
  aboutText: 'I’m a 17-year-old developer focused on AI and machine learning, Minecraft plugins and mods, Discord bots, and modern web products. I care about clean execution, thoughtful details, and shipping work that holds up outside a demo.',
  avatarUrl: '/avatar.jpg',
  skills: [
    { name: 'Languages', skills: ['Python', 'Java', 'TypeScript', 'JavaScript', 'HTML', 'CSS', 'SQL'] },
    { name: 'Minecraft', skills: ['Java', 'Fabric', 'Mixin', 'Gradle'] },
    { name: 'Web', skills: ['React', 'Vite', 'Tailwind CSS', 'FastAPI', 'Node.js'] },
    { name: 'ML & Data', skills: ['scikit-learn', 'Pandas', 'NumPy', 'NLP'] },
    { name: 'Tools', skills: ['Git', 'GitHub', 'PostgreSQL', 'VS Code', 'Vercel'] },
  ],
  capabilities: [
    { number: '01', title: 'Discord bots', copy: 'Reliable commands, dashboards, and automation that save time.' },
    { number: '02', title: 'Minecraft mods', copy: 'Fabric experiences built for clients, servers, and communities.' },
    { number: '03', title: 'Web products', copy: 'Fast, responsive interfaces and practical full-stack applications.' },
    { number: '04', title: 'Applied ML', copy: 'Classifiers, data pipelines, and focused experiments with real utility.' },
  ],
  socialLinks: [
    { id: 'discord', label: 'Discord', handle: '@devilsuckss', description: 'The fastest way to reach me.', url: 'https://discord.com/users/devilsuckss' },
    { id: 'github', label: 'GitHub', handle: 'Devil-6967', description: 'Code, experiments, and current builds.', url: 'https://github.com/Devil-6967' },
    { id: 'profile', label: 'Profile', handle: 'guns.lol/devilsuckss', description: 'More links and ways to connect.', url: 'https://guns.lol/devilsuckss' },
  ],
  projects: [
    { id: 'prime', title: 'prime', year: '2026', status: 'in development', category: 'android', summary: 'a real-time ai voice agent for android with fast conversational responses.', features: ['gemini live voice interaction', 'configurable api architecture', 'android 16 compatibility'], technologies: ['android', 'gemini live', 'ai apis'], featured: true },
    { id: 'no-friendly-fire', title: 'no friendly fire', year: '2026', status: 'in development', category: 'minecraft', summary: 'a minecraft utility mod that detects nearby players and helps keep situational awareness clear.', features: ['nearby player detection', 'fabric and mixin integration', 'lightweight client-side utility'], technologies: ['minecraft', 'fabric', 'mixin', 'gradle'] },
    { id: 'discord-username-finder', title: 'discord username finder', year: '2026', status: 'utility', category: 'discord', summary: 'a clean utility for discord identity lookup and public information.', features: ['username lookup', 'discord api integration', 'fast information presentation'], technologies: ['discord api', 'web'] },
    { id: 'divine', title: 'divine', year: '2026', status: 'in development', category: 'discord', summary: 'a private discord security bot built around responsive server protection.', features: ['security event monitoring', 'modular protection systems', 'real-time event processing'], technologies: ['discord api', 'automation'] },
    { id: 'wick', title: 'wick', year: '2026', status: 'private project', category: 'desktop', summary: 'a private text-based ai system for focused personal computer workflows.', features: ['qwen 3.5 27b integration', 'custom ai interface', 'private model workflows'], technologies: ['qwen 3.5 27b', 'desktop'] },
    { id: 'demon', title: 'demon', year: '2026', status: 'in development', category: 'desktop', summary: 'a personal assistant exploring natural-language computer interaction.', features: ['multi-model ai architecture', 'computer automation', 'application interaction'], technologies: ['gpt-6 astra', 'gemini live'] },
    { id: 'aura', title: 'aura', year: 'retired', status: 'retired experiment', category: 'ai', summary: 'a retired autonomous ai experiment focused on agents, automation boundaries, and safety.', features: ['agent architecture research', 'permission boundaries', 'controlled experimentation'], technologies: ['ai agents', 'automation'] },
  ],
}

const supplied = window.YAHYA_PORTFOLIO_CONFIG ?? {}
export const portfolioConfig: PortfolioConfig = { ...defaults, ...supplied, skills: supplied.skills ?? defaults.skills, capabilities: supplied.capabilities ?? defaults.capabilities, socialLinks: supplied.socialLinks ?? defaults.socialLinks, projects: supplied.projects ?? defaults.projects }
