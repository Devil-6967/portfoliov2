export type PageId = 'home' | 'music' | 'projects' | 'stack' | 'links' | 'contact'

export interface Project {
  id: string
  title: string
  year: string
  status: string
  category: 'ai' | 'discord' | 'android' | 'minecraft' | 'desktop'
  summary: string
  features: string[]
  technologies: string[]
  featured?: boolean
}
