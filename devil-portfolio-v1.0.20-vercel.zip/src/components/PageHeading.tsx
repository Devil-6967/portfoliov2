interface PageHeadingProps {
  id: string
  number: string
  eyebrow: string
  title: string
  description: string
}

export function PageHeading({ id, number, eyebrow, title, description }: PageHeadingProps) {
  return (
    <div className="page-heading">
      <p className="eyebrow"><span>{number}</span> / {eyebrow}</p>
      <h1 id={id}>{title}</h1>
      <p className="page-description">{description}</p>
    </div>
  )
}
