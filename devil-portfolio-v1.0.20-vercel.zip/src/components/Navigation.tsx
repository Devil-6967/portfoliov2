import { useLayoutEffect, useRef } from 'react'
import { Braces, BriefcaseBusiness, Link2, MessageCircle } from 'lucide-react'
import { portfolioConfig } from '../config'
import type { PageId } from '../types'

const items = [
  { id: 'projects', label: 'Projects', icon: BriefcaseBusiness },
  { id: 'stack', label: 'Stack', icon: Braces },
  { id: 'links', label: 'Links', icon: Link2 },
  { id: 'contact', label: 'Contact', icon: MessageCircle },
] as const

const musicCovers = [
  'https://image-cdn-ak.spotifycdn.com/image/ab67616d00001e02241d955916998a678741e961',
  'https://image-cdn-ak.spotifycdn.com/image/ab67616d00001e027f8fad01e767ea1f21765653',
  'https://pickasso.spotifycdn.com/image/ab67c0de0000deef/dt/v1/img/radio/artist/2oBG74gAocPMFv6Ij9ykdo/en',
  'https://image-cdn-ak.spotifycdn.com/image/ab67706c0000da8474c74a176a6537b4826e8f4b',
  'https://mosaic.scdn.co/300/ab67616d00001e0200e1fc57d50c9870e681d10dab67616d00001e023966a33ea1a4708c38605f5cab67616d00001e02a853b902decce7830d171841ab67616d00001e02f071af0f529bd9efe38ad250',
  'https://mosaic.scdn.co/300/ab67616d00001e027bff89cf90806ae22a6b72dfab67616d00001e028630ce04dcdf0c89f218b7d8ab67616d00001e02b8a4fa0168c52aa15ca9f882ab67616d00001e02f5da0af2725ce8121f7b4011',
  'https://image-cdn-ak.spotifycdn.com/image/ab67616d00001e0270b4e28fc2618a1c58f0fcdb',
  'https://mosaic.scdn.co/300/ab67616d00001e02813713582dcc508e7d5073c4ab67616d00001e029b93b7071e8f0d9e14aa5d1cab67616d00001e02edc2353e182ebc8ed13aca99ab67616d00001e02f27e4bdc58ebe249a6b90da0',
  'https://mosaic.scdn.co/300/ab67616d00001e0214b1d3d9f658d9a2fe1d193bab67616d00001e0252bce323f3048a6cffd455f5ab67616d00001e0283842d495f8779031962ab6aab67616d00001e02f8a812f80c6522f51045edfb',
  'https://mosaic.scdn.co/300/ab67616d00001e0258397d59e15b5149adf86033ab67616d00001e026e7b5231a4e16b8013f49e1aab67616d00001e02c85e9cfe721fb577d79a2b54ab67616d00001e02f7d2a56220308f87f643ef4d',
  'https://mosaic.scdn.co/300/ab67616d00001e0233342c57a9b2c4e04c97b3f5ab67616d00001e02495ce6da9aeb159e94eaa453ab67616d00001e02897f73256b9128a9d70eaf66ab67616d00001e02ba5db46f4b838ef6027e6f96',
  'https://image-cdn-ak.spotifycdn.com/image/ab67706c0000da84c58372a4c4b7956d6c86642e',
]

function pickMusicCover() {
  try {
    const previousIndex = Number(window.localStorage.getItem('devil-music-cover'))
    const hasPrevious = Number.isInteger(previousIndex) && previousIndex >= 0 && previousIndex < musicCovers.length
    const nextIndex = hasPrevious
      ? (previousIndex + 1 + Math.floor(Math.random() * (musicCovers.length - 1))) % musicCovers.length
      : Math.floor(Math.random() * musicCovers.length)
    window.localStorage.setItem('devil-music-cover', String(nextIndex))
    return musicCovers[nextIndex]
  } catch {
    return musicCovers[Math.floor(Math.random() * musicCovers.length)]
  }
}

const musicCover = pickMusicCover()

interface NavigationProps {
  activePage: PageId
  onNavigate: (page: PageId) => void
}

export function Navigation({ activePage, onNavigate }: NavigationProps) {
  const dockRef = useRef<HTMLElement>(null)

  useLayoutEffect(() => {
    const dock = dockRef.current
    if (!dock) return

    const positionIndicator = () => {
      const activeItem = dock.querySelector<HTMLElement>('.is-active')
      if (!activeItem) return
      dock.style.setProperty('--indicator-x', `${activeItem.offsetLeft}px`)
      dock.style.setProperty('--indicator-y', `${activeItem.offsetTop}px`)
      dock.style.setProperty('--indicator-width', `${activeItem.offsetWidth}px`)
      dock.style.setProperty('--indicator-height', `${activeItem.offsetHeight}px`)
    }

    positionIndicator()
    const observer = new ResizeObserver(positionIndicator)
    observer.observe(dock)
    return () => observer.disconnect()
  }, [activePage])

  return (
    <nav className="dock" aria-label="Primary navigation" ref={dockRef}>
      <span className="dock-indicator" aria-hidden="true" />
      <a className={`dock-brand glint${activePage === 'home' ? ' is-active' : ''}`} href="#home" aria-label="home" data-label="home" onClick={(event) => { event.preventDefault(); onNavigate('home') }}>
        <img src={portfolioConfig.avatarUrl} alt="" width="736" height="736" />
      </a>
      <span className="dock-rule" aria-hidden="true" />
      {items.map(({ id, label, icon: Icon }) => (
        <a key={id} className={`dock-link glint${activePage === id ? ' is-active' : ''}`} href={`#${id}`} aria-current={activePage === id ? 'page' : undefined} aria-label={label.toLowerCase()} data-label={label.toLowerCase()} onClick={(event) => { event.preventDefault(); onNavigate(id) }}>
          <Icon size={18} strokeWidth={1.6} aria-hidden="true" />
        </a>
      ))}
      <a className={`dock-link dock-music-cover glint${activePage === 'music' ? ' is-active' : ''}`} href="#music" aria-current={activePage === 'music' ? 'page' : undefined} aria-label="music" data-label="music" onClick={(event) => { event.preventDefault(); onNavigate('music') }}>
        <img src={musicCover} alt="" width="42" height="42" />
      </a>
    </nav>
  )
}
